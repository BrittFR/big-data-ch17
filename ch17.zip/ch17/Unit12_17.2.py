# exercise_17_2.py

import sqlite3

def exercise_17_2():
    conn = sqlite3.connect("books.db")
    cursor = conn.cursor()

    print("\n Exercise 17.2:")

    # Select all from titles table
    cursor.execute("SELECT * FROM titles")
    rows = cursor.fetchall()

    # Use description to get column names
    headers = [desc[0] for desc in cursor.description]
    print(" | ".join(headers))

    for row in rows:
        print(" | ".join(str(cell) for cell in row))

    conn.close()
    print(" Exercise 17.2 complete.")

exercise_17_2()
