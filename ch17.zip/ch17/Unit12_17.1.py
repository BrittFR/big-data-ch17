# exercise_17_1.py

import sqlite3

def exercise_17_1():
    conn = sqlite3.connect("books.db")
    cursor = conn.cursor()

    print("\n Exercise 17.1:")

    # a) All authors' last names in descending order
    print("\na) Authors' last names (DESC):")
    cursor.execute("SELECT last FROM authors ORDER BY last DESC")
    for row in cursor.fetchall():
        print(row[0])

    # b) All book titles in ascending order
    print("\nb) Book titles (ASC):")
    cursor.execute("SELECT title FROM titles ORDER BY title ASC")
    for row in cursor.fetchall():
        print(row[0])

    # c) INNER JOIN: all books for a specific author
    print("\nc) Books for author 'Deitel':")
    cursor.execute("""
        SELECT titles.title, titles.copyright, titles.isbn 
        FROM authors 
        JOIN author_ISBN ON authors.id = author_ISBN.id 
        JOIN titles ON author_ISBN.isbn = titles.isbn 
        WHERE authors.last = 'Deitel'
        ORDER BY titles.title
    """)
    for row in cursor.fetchall():
        print(row)

    # d) Insert a new author
    print("\nd) Inserting new author: Jane Doe")
    cursor.execute("INSERT INTO authors (first, last) VALUES (?, ?)", ("Jane", "Doe"))

    # e) Insert a new title and link to new author
    print("\ne) Inserting new book and linking to Jane Doe")
    cursor.execute("INSERT INTO titles (isbn, title, edition, copyright) VALUES (?, ?, ?, ?)",
                   ("9999999999", "Big Data Basics", 1, "2025"))

    # Fetch the new author's ID
    cursor.execute("SELECT id FROM authors WHERE first='Jane' AND last='Doe'")
    jane_doe_id = cursor.fetchone()[0]

    # Link book to Jane Doe
    cursor.execute("INSERT INTO author_ISBN (id, isbn) VALUES (?, ?)", (jane_doe_id, "9999999999"))

    conn.commit()
    conn.close()
    print(" Exercise 17.1 complete.")

exercise_17_1()
